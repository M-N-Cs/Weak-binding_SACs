import os
import shutil

for root, dirs, files in os.walk("."):
    for file in files:
        if root == ".":
            if file.endswith("H2O"):
                os.remove(os.path.join(root, file))
                continue
            if file.endswith("OH") or file.endswith("OOH") or file.endswith("O2") or file.endswith("H2O2") or file.endswith("O"):
                shutil.copyfile(os.path.join(root, file), os.path.join(root, "adsorbates", file))
                os.remove(os.path.join(root, file))